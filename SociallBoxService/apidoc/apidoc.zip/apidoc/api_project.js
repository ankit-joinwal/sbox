define({
  "name": "SociallBox API",
  "version": "1.0.0",
  "description": "SociallBox Server API Specifications",
  "title": "SociallBox API",
  "url": "http://<<host>>:<<port>",
  "sampleUrl": false,
  "apidoc": "0.2.0",
  "generator": {
    "name": "apidoc",
    "time": "2016-05-07T10:03:48.452Z",
    "url": "http://apidocjs.com",
    "version": "0.15.0"
  }
});
