define({
  "name": "SociallBox API",
  "version": "1.0.0",
  "description": "SociallBox Server API Specifications",
  "title": "SociallBox API",
  "url": "http://<<host>>:<<port>/SociallBox",
  "sampleUrl": false,
  "apidoc": "0.2.0",
  "generator": {
    "name": "apidoc",
    "time": "2016-05-01T13:36:58.862Z",
    "url": "http://apidocjs.com",
    "version": "0.15.0"
  }
});
